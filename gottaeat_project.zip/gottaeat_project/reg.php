
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<?php
    
    $pdo = new PDO("mysql:host=localhost;dbname=projectdbms;charset=utf8","root","");
    if($_POST['Password'] != $_POST['Password2']){ 
        echo'<script>swal("รหัสผ่านไม่ตรงกัน");setTimeout(function() {
            window.location.href = "./register.php";
        }, 3000);</script>';
        exit();    
    }
    else {
        echo'<script>swal("เรียบร้อย");setTimeout(function() {
            window.location.href = "./login.php";
        }, 3000);</script>';
    }
    


    $ckuser = $pdo->prepare("SELECT * FROM customer WHERE Email = ?");
    $ckuser->execute([$_POST['Email']]);
    if($ckuser->rowCount() != 0){
        echo'<script>swal("มี Email นี้ ในระบบอยู่แล้ว");setTimeout(function() {
            window.location.href = "./register.php";
        }, 3000)</script>';
        exit();

        echo "มี username นีในระบบอยู่แล้ว";
    }
    
    $stmt = $pdo->prepare("INSERT INTO customer (Email,Name,Age,TEL,Password) values (?,?,?,?,?)");
    $stmt->bindParam(1, $_POST["Email"]);
    $stmt->bindParam(2, $_POST["Name"]);
    $stmt->bindParam(3, $_POST["Age"]);
    $stmt->bindParam(4, $_POST["TEL"]);
    $stmt->bindParam(5, $_POST["Password"]);
    $stmt->execute();

    header("location:login.php");
   

?>
</body>
</html>