<?php   
 session_start();  
 $pdo = new PDO("mysql:host=localhost;dbname=projectdbms;charset=utf8","root","");
 $connect = mysqli_connect("localhost", "root", "", "projectdbms");  
 if(isset($_GET['save'])){
     if(!empty($_SESSION["shopping_cart"]))  
     {  
          $irOrder = rand(1000,9999);
		$addOrder = $pdo->prepare("INSERT INTO `oder`(`OCode`, `uid`) VALUES (?,?)");
		$addOrder->execute([$irOrder,$_SESSION['uid']]);
          foreach($_SESSION["shopping_cart"] as $keys => $values)  
          {  
               $addtoCart = $pdo->prepare("INSERT INTO `morder`(`cusID`, `MOCode`, `MName`, `Qty`) VALUES (?,?,?,?)");
               $addtoCart->execute([$_SESSION['uid'],$irOrder,$values['item_name'],$values['item_quantity']]);
          } 
          unset($_SESSION["shopping_cart"]);
          echo "<script>window.location.href='cart.php?OCode=".$irOrder."'</script>";
     }  
 }



 if(isset($_POST["add_to_cart"])) 
 {  
      if(isset($_SESSION["shopping_cart"]))  
      {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");  
 
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'item_id'               =>     $_GET["id"],  
                     'item_name'             =>     $_POST["hidden_name"],  
                     'item_price'            =>     $_POST["hidden_price"],  
                     'item_quantity'         =>     $_POST["quantity"]  
                );  
                $_SESSION["shopping_cart"][$count] = $item_array;  
            
      }  
      else  
      {  
           $item_array = array(  
                'item_id'               =>     $_GET["id"],  
                'item_name'             =>     $_POST["hidden_name"],  
                'item_price'            =>     $_POST["hidden_price"],  
                'item_quantity'         =>     $_POST["quantity"]  
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
      }  
 }  
 if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "delete")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["item_id"] == $_GET["id"])  
                {  
                     unset($_SESSION["shopping_cart"][$keys]);  
                     echo '<script>alert("Item Removed")</script>';  
                     echo '<script>window.location="order_db.php"</script>';  
                }  
           }  
      }  
 }  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
        
          <link href="css/fontawesome-free-5.15.3-web/css/all.css" rel="stylesheet">
          <link rel="stylesheet" href="img/user-friends-solid.svg">
          
           <title>Webslesson Tutorial | Simple PHP Mysql Shopping Cart</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
           <link rel="stylesheet" href="css\oder_css.css">
           <link href="img/shopping-cart-solid.svg" rel="stylesheet">
      <style>
          img {
          width: 100% !important;
          height: 100px !important;
          object-fit: contain
          }
          #center{
               text-align : center;
          }
      </style>
      </head>  
      <body>
           
           <div class="headder">
                         <div class="navbar">
                            <a href="index.php" class="topic">Home</a>
                            <a href="order_db.php" class="topic">Menu</a>
                            <a href="cart.php" class="topic">Reciept</a>
                            <a href="my-account.php" class="topic">My Account</a>
                            <span style="padding-top: 5px">
                                <i class="fas fa-user-friends"></i>
                                <?php 
                         
                                    if(isset($_SESSION['Email'])){
                                        echo $_SESSION['Email'];
                                    }

                                    else{
                                        header ("location:login.php"); 
                                        
                                    } 
                                ?> 
                            </span>
                        </div>
           </div>
           
           <br/>  
           <div class="container" style="width:650px; background-color:#FF6F61; color: white; padding-top:2px;  padding-bottom:2px; border-radius: 25px; ">
               <h1 align="center">MENU</h1>
          </div>
          <div >
               <a href="#Ltable" class="btn cart">
                    <i class="fas fa-shopping-cart" style="position:fixed; right:200px; widht:20px;"></i>
               </a>
          </div>
           <div class="container" style="width:700px;">  
              
                <?php  
                $query = "SELECT * FROM menu ORDER BY MID ASC";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>  
                
               <div class="col-md-4">  
                
                     <form method="post" action="order_db.php?action=add&id=<?php echo $row["MID"]; ?>">  
                          <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">  
                                <img src="img/<?php echo $row['imag']?>" alt=""><br/>  
                               <h4 class="text-info"><?php echo $row["MName"]; ?></h4>  
                               <h4 class="text-danger">฿ <?php echo $row["MPrice"]; ?></h4>  
                               <input type="number" max="10" name="quantity" class="form-control" value="1"/>  
                               <input type="hidden" name="hidden_name" value="<?php echo $row["MName"]; ?>" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $row["MPrice"]; ?>" />  
                               <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />  
                          </div>  <br>
                     </form>  
                </div>  
                <?php  
                     }  
                }  
                ?>  
                <div style="clear:both"></div>  
                <br />  
              
                <div class="table-responsive">  
                     <table class="table table-bordered" id="Ltable">  
                          <tr>  
                               <th width="40%">Menu</th>  
                               <th width="10%">Quantity</th>  
                               <th width="20%">Price</th>  
                               <th width="15%">Total</th>  
                               <th width="5%">Action</th>  
                          </tr>  
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                               <td><?php echo $values["item_name"]; ?></td>  
                               <td><?php echo $values["item_quantity"]; ?></td>  
                               <td>฿ <?php echo $values["item_price"]; ?></td>  
                               <td>฿ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>  
                               <td><a href="order_db.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>  
                          </tr>  
                          <?php  
                                    $total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }  
                          ?>  
                          <tr>  
                               <td colspan="3" align="right">Total</td>  
                               <td align="right">฿ <?php echo number_format($total, 2); ?></td>  
                               <td></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>
                     <div id="center">
                         <a href="?save"><input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Send order" /></a>
                         
                    </div>
                </div>  
                
           </div>  
           <br/>  
      </body>  
 </html>
   