<!DOCTYPE html>
<html lang="en">
<?php
    session_start();
?>
    <head>
        <meta charset="utf-8">
        <title>E Store - eCommerce HTML Template</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="eCommerce HTML Template Free Download" name="keywords">
        <meta content="eCommerce HTML Template Free Download" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400|Source+Code+Pro:700,900&display=swap" rel="stylesheet">

        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/slick/slick.css" rel="stylesheet">
        <link href="lib/slick/slick-theme.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    </head>

    <body>

        <!-- Top bar Start -->
     
        <!-- Top bar End -->
        
        <!-- Nav Bar Start -->
        <div class="nav">
            <div class="container-fluid">
                <nav class="navbar navbar-expand-md bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <a href="admin.php" class="nav-item nav-link">Home</a>
                            <a href="insertmenu.php" class="nav-item nav-link active">insertmenu</a>
                            <a href="List_order.php" class="nav-item nav-link">Check Order</a>
                            <!-- <a href="accept.php" class="nav-item nav-link">accept menu</a> -->
                            <!-- <p>My Account :</p> -->
                            <div style="padding-top: 5px">
                                <i class="fas fa-user-friends"></i>
                                <?php 
                                
                                    if(isset($_SESSION['Email'])){
                                        echo $_SESSION['Email'] ;
                                    }
                                    else{
                                        header ("location:login.php"); 
                                        
                                    } 
                                ?> 
                            </div>
                        </div>
                        </div>
                        
                        <div class="navbar-nav ml-auto">
                            <div class="nav-item dropdown">
                                <a  href="logout.php" class="dropdown-item">Logout</a>
                               
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Nav Bar End -->      
        
        <!-- Bottom Bar Start -->
        <div class="bottom-bar">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-3">
                        <div class="logo">
                            <a href="index.html">
                                <img src="img/logoGotta.png" alt="Logo" style="border-radius:50px;" >
                            </a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- Bottom Bar End --> 
<form method="POST" action="menuadd.php">
            <div class="login">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-6">    
                            <div class="register-form">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>MID</label>
                                        <input class="form-control" type="text" placeholder="MID" name="MID" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>ชื่อเมนู</label> 
                                        <input class="form-control" type="text" placeholder="MName"  name="MName" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Age</label>
                                        <input class="form-control" type="number" placeholder="MPrice"  name="MPrice" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Age</label>
                                        <input class="form-control" type="file" placeholder="choose change name like MID"  name="imag" required>
                                    </div>
 
                                    <div class="col-md-12">
                                        <button class="btn">เพิ่มข้อมูล</button>
                                    </div>

                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            
        </form>   
        </body>
</html>