
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<?php
    
    $pdo = new PDO("mysql:host=localhost;dbname=projectdbms;charset=utf8","root","");
    
    
    
    $stmt = $pdo->prepare("INSERT INTO menu (MID,MName,MPrice,imag) values (?,?,?,?)");
    $stmt->bindParam(1, $_POST["MID"]);
    $stmt->bindParam(2, $_POST["MName"]);
    $stmt->bindParam(3, $_POST["MPrice"]);
    $stmt->bindParam(4, $_POST["imag"]);
    $stmt->execute();
    echo'<script>swal("<b>เพิ่มข้อมูลสำเร็จ</b>");</script>';
    header("location:insertmenu.php");
   

?>
</body>
</html>