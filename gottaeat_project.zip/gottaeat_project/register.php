<!DOCTYPE html>
<html lang="en">
<?php
    session_start();
?>
    <head>
        <meta charset="utf-8">
        <title>E Store - eCommerce HTML Template</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="eCommerce HTML Template Free Download" name="keywords">
        <meta content="eCommerce HTML Template Free Download" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400|Source+Code+Pro:700,900&display=swap" rel="stylesheet">

        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/slick/slick.css" rel="stylesheet">
        <link href="lib/slick/slick-theme.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    </head>

    <body>

        <!-- Top bar Start -->
     
        <!-- Top bar End -->
        
        <!-- Nav Bar Start -->
        <div class="nav">
            <div class="container-fluid">
                <nav class="navbar navbar-expand-md bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <a href="index.php" class="nav-item nav-link">Home</a>
                            <a href="order_db.php" class="nav-item nav-link">Menu</a>
                            <a href="cart.php" class="nav-item nav-link">Reciept</a>
                            <a href="my-account.php" class="nav-item nav-link">My Account</a>
                        </div>
                        <div class="navbar-nav ml-auto">
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">User Account</a>
                                <div class="dropdown-menu">
                                    <a href="login.php" class="dropdown-item">Login</a>
                                    <a href="register.php" class="dropdown-item">Register</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Nav Bar End -->      
        
        <!-- Bottom Bar Start -->
        <div class="bottom-bar">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-3">
                        <div class="logo">
                            <a href="index.html">
                                <img src="img/logoGotta.png" alt="Logo" style="border-radius:50px;" >
                            </a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- Bottom Bar End --> 
        
        <!-- Breadcrumb Start -->
        <div class="breadcrumb-wrap">
            <div class="container-fluid">
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="Menu.php">Menu</a></li>
                    <li class="breadcrumb-item active">Register</li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb End -->
        
        <!-- Login Start -->
        <form method="POST" action="reg.php">
            <div class="login">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-6">    
                            <div class="register-form">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>E-mail</label>
                                        <input class="form-control" type="email" placeholder="E-mail" name="Email" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Name</label> 
                                        <input class="form-control" type="text" placeholder="Name"  name="Name" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Age</label>
                                        <input class="form-control" type="number" placeholder="Age"  name="Age" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Phone number</label>
                                        <input class="form-control" type="text" placeholder="Tel"  name="TEL" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Password</label>
                                        <input class="form-control" type="password" placeholder="Password" name="Password" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Confirm password</label>
                                        <input class="form-control" type="password" placeholder="Password" name="Password2" required>
                                    </div>
 
                                    <div class="col-md-12">
                                        <button class="btn">Sign up</button>
                                    </div>

                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            
        </form>   
         
        <?php   
            // $pdo = new PDO("mysql:host=localhost;dbname=projectdbms;charset=utf8","root","");
            // // if($_POST['Password'] != $_POST['Password2']){ 
            // //     echo'<script>swal("รหัสผ่านไม่ตรงกัน");</script>';
            // //     exit();    
            // // }
            // // else {
            // //     echo'<script>swal("เรียบร้อย");</script>';
            // // }
            // //echo'<script>swal("เรียบร้อย");</script>';
            // $stmt = $pdo->prepare("INSERT INTO customer (Email,Name,Age,TEL,Password) values (?,?,?,?,?)");
            // // $ckuser = $pdo->prepare("SELECT * FROM customer WHERE Email = ?");
            // // $ckuser->execute([$_POST['Email']]);
            // // if($ckuser->rowCount() != 0){
            // //     echo'<script>swal("มี Email นี้ ในระบบอยู่แล้ว");</script>';
            // //     exit();

            // //     //echo "มี Email นีในระบบอยู่แล้ว";
            // // }
            
            // $stmt->bindParam(1, $_POST["Email"]);
            // $stmt->bindParam(2, $_POST["Name"]);
            // $stmt->bindParam(3, $_POST["Age"]);
            // $stmt->bindParam(4, $_POST["TEL"]);
            // $stmt->bindParam(5, $_POST["Password"]);
            // $stmt->execute();
            // //header("location:login.php");
       
        ?>

       
 
        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/slick/slick.min.js"></script>
        
        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>
</html>
