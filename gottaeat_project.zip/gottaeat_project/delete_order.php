<?php
// include "login.php";
session_start();

$pdo = new PDO("mysql:host=localhost;dbname=projectdbms;charset=utf8", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt = $pdo->prepare("DELETE FROM oder WHERE status = "1"");
$stmt->bindParam(1, $_POST["oderID"]);
$stmt->execute();

Header("Location: List_order.php");